﻿namespace Arong_Menu
{
	partial class Form_main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_main));
			this.panel1 = new System.Windows.Forms.Panel();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.pictureBox10 = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.Show_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.Exit_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BackColor = System.Drawing.Color.Transparent;
			this.panel1.Location = new System.Drawing.Point(153, 37);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(798, 485);
			this.panel1.TabIndex = 3;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// toolTip1
			// 
			this.toolTip1.AutoPopDelay = 5000;
			this.toolTip1.InitialDelay = 500;
			this.toolTip1.ReshowDelay = 100;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox2.Location = new System.Drawing.Point(17, 20);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(100, 30);
			this.pictureBox2.TabIndex = 10;
			this.pictureBox2.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox2, "用于快速切换许可");
			this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
			this.pictureBox2.MouseEnter += new System.EventHandler(this.pictureBox2_MouseEnter);
			this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
			// 
			// pictureBox3
			// 
			this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox3.Location = new System.Drawing.Point(17, 56);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(100, 30);
			this.pictureBox3.TabIndex = 11;
			this.pictureBox3.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox3, "用于快速切换许可");
			this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
			this.pictureBox3.MouseEnter += new System.EventHandler(this.pictureBox3_MouseEnter);
			this.pictureBox3.MouseLeave += new System.EventHandler(this.pictureBox3_MouseLeave);
			// 
			// pictureBox4
			// 
			this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox4.Location = new System.Drawing.Point(17, 399);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(100, 30);
			this.pictureBox4.TabIndex = 12;
			this.pictureBox4.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox4, "软件默认设置");
			this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
			this.pictureBox4.MouseEnter += new System.EventHandler(this.pictureBox4_MouseEnter);
			this.pictureBox4.MouseLeave += new System.EventHandler(this.pictureBox4_MouseLeave);
			// 
			// pictureBox5
			// 
			this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox5.Location = new System.Drawing.Point(17, 435);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(100, 30);
			this.pictureBox5.TabIndex = 13;
			this.pictureBox5.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox5, "点击查看软件更新历史记录");
			this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
			this.pictureBox5.MouseEnter += new System.EventHandler(this.pictureBox5_MouseEnter);
			this.pictureBox5.MouseLeave += new System.EventHandler(this.pictureBox5_MouseLeave);
			// 
			// pictureBox6
			// 
			this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox6.Location = new System.Drawing.Point(17, 164);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new System.Drawing.Size(100, 30);
			this.pictureBox6.TabIndex = 14;
			this.pictureBox6.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox6, "用于快速更新对应版本或者是全部版本的DLL与DLX文件");
			this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
			this.pictureBox6.MouseEnter += new System.EventHandler(this.pictureBox6_MouseEnter);
			this.pictureBox6.MouseLeave += new System.EventHandler(this.pictureBox6_MouseLeave);
			// 
			// pictureBox7
			// 
			this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox7.Location = new System.Drawing.Point(17, 200);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new System.Drawing.Size(100, 30);
			this.pictureBox7.TabIndex = 15;
			this.pictureBox7.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox7, "暂未开发完成");
			this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
			this.pictureBox7.MouseEnter += new System.EventHandler(this.pictureBox7_MouseEnter);
			this.pictureBox7.MouseLeave += new System.EventHandler(this.pictureBox7_MouseLeave);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox1.Location = new System.Drawing.Point(17, 128);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(100, 30);
			this.pictureBox1.TabIndex = 16;
			this.pictureBox1.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox1, "该模块为快速对比对应的文件夹内缺失的文件。");
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			this.pictureBox1.MouseEnter += new System.EventHandler(this.pictureBox1_MouseEnter);
			this.pictureBox1.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
			// 
			// pictureBox8
			// 
			this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox8.Location = new System.Drawing.Point(17, 92);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new System.Drawing.Size(100, 30);
			this.pictureBox8.TabIndex = 17;
			this.pictureBox8.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox8, "暂未开发完成");
			this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
			this.pictureBox8.MouseEnter += new System.EventHandler(this.pictureBox8_MouseEnter);
			this.pictureBox8.MouseLeave += new System.EventHandler(this.pictureBox8_MouseLeave);
			// 
			// pictureBox9
			// 
			this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox9.Location = new System.Drawing.Point(17, 236);
			this.pictureBox9.Name = "pictureBox9";
			this.pictureBox9.Size = new System.Drawing.Size(100, 30);
			this.pictureBox9.TabIndex = 18;
			this.pictureBox9.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox9, "提供快捷小工具");
			this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
			this.pictureBox9.MouseEnter += new System.EventHandler(this.pictureBox9_MouseEnter);
			this.pictureBox9.MouseLeave += new System.EventHandler(this.pictureBox9_MouseLeave);
			// 
			// pictureBox10
			// 
			this.pictureBox10.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox10.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox10.Location = new System.Drawing.Point(17, 272);
			this.pictureBox10.Name = "pictureBox10";
			this.pictureBox10.Size = new System.Drawing.Size(100, 30);
			this.pictureBox10.TabIndex = 19;
			this.pictureBox10.TabStop = false;
			this.toolTip1.SetToolTip(this.pictureBox10, "环境变量小工具");
			this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
			this.pictureBox10.MouseEnter += new System.EventHandler(this.pictureBox10_MouseEnter);
			this.pictureBox10.MouseLeave += new System.EventHandler(this.pictureBox10_MouseLeave);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox1.Controls.Add(this.pictureBox2);
			this.groupBox1.Controls.Add(this.pictureBox5);
			this.groupBox1.Controls.Add(this.pictureBox4);
			this.groupBox1.Controls.Add(this.pictureBox10);
			this.groupBox1.Controls.Add(this.pictureBox3);
			this.groupBox1.Controls.Add(this.pictureBox9);
			this.groupBox1.Controls.Add(this.pictureBox6);
			this.groupBox1.Controls.Add(this.pictureBox8);
			this.groupBox1.Controls.Add(this.pictureBox7);
			this.groupBox1.Controls.Add(this.pictureBox1);
			this.groupBox1.Location = new System.Drawing.Point(12, 37);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(135, 485);
			this.groupBox1.TabIndex = 20;
			this.groupBox1.TabStop = false;
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Show_ToolStripMenuItem,
            this.Exit_ToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(101, 48);
			// 
			// Show_ToolStripMenuItem
			// 
			this.Show_ToolStripMenuItem.Name = "Show_ToolStripMenuItem";
			this.Show_ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
			this.Show_ToolStripMenuItem.Text = "显示";
			this.Show_ToolStripMenuItem.Click += new System.EventHandler(this.Show_ToolStripMenuItem_Click);
			// 
			// Exit_ToolStripMenuItem
			// 
			this.Exit_ToolStripMenuItem.Name = "Exit_ToolStripMenuItem";
			this.Exit_ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
			this.Exit_ToolStripMenuItem.Text = "退出";
			this.Exit_ToolStripMenuItem.Click += new System.EventHandler(this.Exit_ToolStripMenuItem_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "提效工具箱后台服务";
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
			// 
			// Form_main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
			this.ClientSize = new System.Drawing.Size(960, 540);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.panel1);
			this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.Location = new System.Drawing.Point(50, 50);
			this.MinimumSize = new System.Drawing.Size(960, 540);
			this.Name = "Form_main";
			this.Shadow = true;
			this.ShadowWidth = 15;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "提效工具箱_V3.1";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_main_FormClosed);
			this.Load += new System.EventHandler(this.Form_main_Load);
			this.SizeChanged += new System.EventHandler(this.Form_main_SizeChanged);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form_main_KeyDown);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.PictureBox pictureBox9;
		private System.Windows.Forms.PictureBox pictureBox10;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem Show_ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem Exit_ToolStripMenuItem;
		public System.Windows.Forms.NotifyIcon notifyIcon1;
	}
}