﻿using CCWin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arong_Core;

namespace Arong_Menu
{
	public partial class Icon_Assistant : Skin_DevExpress
	{
		public Icon_Assistant()
		{
			InitializeComponent();

			//显示用户设置的背景色
			this.BackColor = Properties.Settings.Default.Tools_color;
		}

		private void Icon_Assistant_Load(object sender, EventArgs e)
		{

		}
	}
}
