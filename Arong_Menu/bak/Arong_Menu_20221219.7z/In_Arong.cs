﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Arong_Menu
{
	public partial class In_Arong : Form
	{
		public In_Arong()
		{
			InitializeComponent();
			In_Arong in_Arong = new In_Arong();
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void In_Arong_Load(object sender, EventArgs e)
		{
			Color a =	In_Arong.DefaultBackColor;
			
		}
	}
}
