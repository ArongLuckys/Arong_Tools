﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arong_New;
using System.IO;

namespace Arong_Menu
{
	internal static class Program
	{
		/// <summary>
		/// 应用程序的主入口点。
		/// </summary>
		[STAThread]
		static void Main()
		{
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form_main());
   //         string path = Arong_New.New.Arong_str()+"\\Key.Arong";
			//if (File.Exists(path) == true)
			//{

			//}
			//else
			//{
   //             MessageBox.Show("您没有权限使用本软件" + "\n联系QQ:2786217208");
   //             //强制退出该程序
   //             System.Diagnostics.Process tt = System.Diagnostics.Process.GetProcessById(System.Diagnostics.Process.GetCurrentProcess().Id);
   //         }
		}
	}
}
