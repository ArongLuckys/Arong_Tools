﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arong_File;

namespace Arong_Menu
{
    public partial class License_switching : UserControl
    {
        public License_switching()
        {
            InitializeComponent();
            label2.Text = Properties.Settings.Default.files_path;
            label3.Text = Arong_File.Arong_File.File_Lic_Name(Properties.Settings.Default.files_path,Arong_File.Arong_File.File_Lic_Use_Path());
        }

        //选择路径
        private void button1_Click(object sender, EventArgs e)
        {
            //显示对话框
            open_files.ShowDialog();
            //返回对话框所选择的路径
            label2.Text = open_files.SelectedPath;
            //记忆路径
            Properties.Settings.Default.files_path = open_files.SelectedPath;
            //保存路径
            Properties.Settings.Default.Save();
        }

        //文件列表视图
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.SelectedItem = listBox1.SelectedItem.ToString();
            label3.Text = listBox1.SelectedItem.ToString();
        }

        //主窗口
        private void License_switching_Load(object sender, EventArgs e)
        {
            string files_path = Properties.Settings.Default.files_path;
            string[] temps = Arong_File.Arong_File.File_List_App(files_path, Arong_File.Arong_File.File_Lic_Path());
            //循环输出内容
            for (int i = 0; i < temps.Length; i++)
            {
                listBox1.Items.Add(temps[i]);
            }
            //listBox1= new ListBox();

        }

        //中间文本显示
        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        //帮助
        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
