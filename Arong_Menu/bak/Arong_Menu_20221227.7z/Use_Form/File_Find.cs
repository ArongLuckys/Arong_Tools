﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu.Use_Form
{
	public partial class File_Find : UserControl
	{
		public File_Find()
		{
			InitializeComponent();
		}
	}
}
