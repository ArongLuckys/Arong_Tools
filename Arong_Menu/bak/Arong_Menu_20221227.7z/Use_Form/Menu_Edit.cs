﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu
{
    public partial class Menu_Edit : UserControl
    {
        public Menu_Edit()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Menu_Edit_Load(object sender, EventArgs e)
        {

        }

        //生成功能
        private void button1_Click(object sender, EventArgs e)
        {
            Arong_New.New.New_path(menu_edit_box1.Text,menu_edit_box2.Text,menu_edit_box3.Text,menu_edit_box4.Text,menu_edit_box5.Text);
            menu_edit_box1.Clear();
            menu_edit_box2.Clear();
            menu_edit_box3.Clear();
            menu_edit_box4.Clear();
            menu_edit_box5.Clear();

            if (checkBox5.Checked == true)
            {
                MessageBox.Show("功能生成完成");
            }
        }

        //生成菜单
        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
