﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Arong_New;

namespace Arong_Menu
{
	public partial class Form2 : Form
	{
		public Form2()
		{
            InitializeComponent();
		}
		
		//主窗口
		private void Form2_Load(object sender, EventArgs e)
		{

		}

		//创建
		private void button2_Click(object sender, EventArgs e)
		{
			//生成文件
			Arong_New.New.New_path(textBox1.Text,textBox2.Text,textBox3.Text,textBox4.Text,textBox5.Text);

			//清空输入框
			textBox1.Clear();
			textBox2.Clear();
			textBox3.Clear();
			textBox4.Clear();
			textBox5.Clear();
		}
	}
}
