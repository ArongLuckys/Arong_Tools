﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu
{
    public partial class Form4 : Form
    {
        public Visual_Editor Visual_Editor;
        public Form4()
        {
            InitializeComponent();
            Visual_Editor = new Visual_Editor();
        }

        //主窗口
        private void Form4_Load(object sender, EventArgs e)
        {
            Visual_Editor.Show();
            panel1.Controls.Clear();
            panel1.Controls.Add(Visual_Editor);
        }

        //用户窗口
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
