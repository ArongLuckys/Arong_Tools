﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu
{
	public partial class Nx_Path : Form
	{
		public Nx_Path()
		{
			InitializeComponent();
			string path = Properties.Settings.Default.nx_path;
			textBox1.Text = path;
		}

		//NX路径输入窗口
		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			if (textBox1.Text == "")
			{
				MessageBox.Show("不可以输入空路径");
			}
			else
			{
				Properties.Settings.Default.nx_path = textBox1.Text;
				Properties.Settings.Default.Save();
			}
		}
	}
}
