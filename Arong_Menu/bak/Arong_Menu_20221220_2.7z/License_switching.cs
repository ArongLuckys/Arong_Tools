﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arong_File;
using Arong_New;

namespace Arong_Menu
{
    public partial class License_switching : UserControl
    {
        //判断是否切换许可时结束nx进程
        public static void NX_kills()
        {
            bool temp = Properties.Settings.Default.kill_nx;
            if (temp == true)
            {
                System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("ugraf");
                foreach (System.Diagnostics.Process p in process)
                {
                    p.Kill();
                }
            }
        }

        public License_switching()
        {
            InitializeComponent();
            textBox1.Text = Properties.Settings.Default.files_path;
            checkBox1.Checked = Properties.Settings.Default.lic_sw;
            checkBox2.Checked = Properties.Settings.Default.kill_nx;
        }

        //主窗口
        private void License_switching_Load(object sender, EventArgs e)
        {
            //显示当前使用的许可名称
            label3.Text = Properties.Settings.Default.use;

            string files_path = Properties.Settings.Default.files_path;
            string[] temps = Arong_File.Arong_File.File_List_App(files_path, Arong_File.Arong_File.File_Lic_Path());
            //循环输出内容
            for (int i = 0; i < temps.Length; i++)
            {
                listBox1.Items.Add(temps[i]);
            }
        }

        //中间文本显示
        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        //帮助
        private void button2_Click(object sender, EventArgs e)
        {

        }

        //结束NX进程
		private void button3_Click(object sender, EventArgs e)
		{
            System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("ugraf");
            foreach (System.Diagnostics.Process p in process)
            {
                p.Kill();
            }
            MessageBox.Show("完成");
        }

        //路径输入窗口
		private void textBox1_TextChanged(object sender, EventArgs e)
		{
            Properties.Settings.Default.files_path = textBox1.Text;
            Properties.Settings.Default.Save();
		}

        //许可切换后提示
		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
            if (checkBox1.Checked == false)
            {
                MessageBox.Show("弹窗是为了防止切换过快导致操作系统无法即使相应而弹窗的\n如果不勾选，请不要操作太快");
            }
            Properties.Settings.Default.lic_sw = checkBox1.Checked;
            Properties.Settings.Default.Save();
		}

        //切换时一并结束NX
		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
            Properties.Settings.Default.kill_nx = checkBox2.Checked;
            Properties.Settings.Default.Save();
        }

        //列表视图
		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
            if (Properties.Settings.Default.files_path == "C:\\")
            {
                MessageBox.Show("未指定要切换的许可路径，无法切换许可");
            }
            else
            {
                //显示当前选择的许可
                label3.Text = listBox1.Text;
                //将属性赋值
                Properties.Settings.Default.use = listBox1.Text;
                //存入记忆
                Properties.Settings.Default.Save();
                //对应弹窗状态
                bool sw = Properties.Settings.Default.lic_sw;
                if (sw == true)
                {
                    MessageBox.Show("变更完成，请勿频繁操作");
                }
                NX_kills();
            }
        }

        //启动NX中的右键菜单
		private void ToolStripMenuItem_Click(object sender, EventArgs e)
		{
            Nx_Path nx_Path = new Nx_Path();
            nx_Path.Show();
		}

        //启动NX
		private void button1_Click(object sender, EventArgs e)
		{
            string path = Properties.Settings.Default.nx_path;
            if (path != "C:\\")
            {
                System.Diagnostics.Process.Start(path);
            }
            else
            {
                MessageBox.Show("请先右键设置NX的启动路径");
            }
		}
	}
}
