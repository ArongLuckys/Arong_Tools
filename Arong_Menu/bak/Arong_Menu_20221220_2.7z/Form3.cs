﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            //复选框默认状态
            //create_menu 生成主菜单
            //create_tools 生成工具条
            //create_function 生成功能区
            //create_order 生成命令集
            checkBox4.Checked = Properties.Settings.Default.create_menu;
            checkBox1.Checked = Properties.Settings.Default.create_tools;
            checkBox2.Checked = Properties.Settings.Default.create_function;
            checkBox3.Checked = Properties.Settings.Default.create_order;
        }

        //生成
        private void button1_Click(object sender, EventArgs e)
        {

            //保存勾选信息
            Properties.Settings.Default.create_menu = checkBox4.Checked;
            Properties.Settings.Default.create_tools = checkBox1.Checked;
            Properties.Settings.Default.create_function = checkBox2.Checked;
            Properties.Settings.Default.create_order = checkBox3.Checked;
            Properties.Settings.Default.Save();
        }
        
        //主窗口
        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
