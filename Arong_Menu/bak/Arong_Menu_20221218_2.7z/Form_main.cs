﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arong_File;

namespace Arong_Menu
{
    public partial class Form_main : Form
    {

        public License_switching APP_License_switching;
        public Menu_Edit APP_Menu_Edit;
        public Form_main()
        {
            InitializeComponent();
            APP_License_switching = new License_switching();
            APP_Menu_Edit = new Menu_Edit();
        }

        //呈现窗口

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        //许可切换
        private void button1_Click(object sender, EventArgs e)
        {
            APP_License_switching.Show();
            panel1.Controls.Clear();
            panel1.Controls.Add(APP_License_switching);
        }

        //菜单编辑器
        private void button2_Click(object sender, EventArgs e)
        {
            APP_Menu_Edit.Show();
            panel1.Controls.Clear();
            panel1.Controls.Add(APP_Menu_Edit);
        }

        //帮助助手 
        private void button3_Click(object sender, EventArgs e)
        {

        }

        //主窗口
        private void Form_main_Load(object sender, EventArgs e)
        {
            
        }
    }
}
