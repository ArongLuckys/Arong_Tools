﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Arong_Menu
{
	public partial class Form2 : Form
	{
		public Form2()
		{
            InitializeComponent();
		}
		
		//主窗口
		private void Form2_Load(object sender, EventArgs e)
		{

		}

		//创建
		private void button2_Click(object sender, EventArgs e)
		{
            //获取工具在文件夹中的位置,不包括exe
            string arong_str = System.Environment.CurrentDirectory;

			//功能注释名称
			string arong_label_1 = System.IO.File.ReadAllText(arong_str+ "\\Data\\label_1.txt");
            string arong_name = arong_label_1 + textBox1.Text;
            
			//功能按钮名称
            string arong_label_2 = System.IO.File.ReadAllText(arong_str + "\\Data\\label_2.txt");
            string arong_button = arong_label_2 + textBox2.Text;

            //功能显示名称
            string arong_label_3 = System.IO.File.ReadAllText(arong_str + "\\Data\\label_3.txt");
            string arong_label = arong_label_3 + textBox3.Text;

            //功能位图名称
            string arong_label_4 = System.IO.File.ReadAllText(arong_str + "\\Data\\label_4.txt");
            string arong_bitmap = arong_label_4 + textBox4.Text;

            //功能DLL路径
            string arong_label_5 = System.IO.File.ReadAllText(arong_str + "\\Data\\label_5.txt");
            string arong_actions = arong_label_5 + textBox5.Text + ".dll";
            
			//组合导出
            string arong_sum = arong_name + "\n" + arong_button + "\n" + arong_label + "\n" + arong_bitmap + "\n" + arong_actions; ;

			//创建文件的路径
			string arong_Temp_Menu = arong_str + "\\Button\\"+arong_name+".txt";

			//创建文件
			System.IO.File.WriteAllText(@arong_Temp_Menu, arong_sum);

			//清空输入框
			textBox1.Clear();
			textBox2.Clear();
			textBox3.Clear();
			textBox4.Clear();
			textBox5.Clear();
		}
	}
}
