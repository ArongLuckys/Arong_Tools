﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arong_Menu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        //生成
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                MessageBox.Show("选中");
            }
            else
            {
                MessageBox.Show("未选中");
            }
        }
    }
}
